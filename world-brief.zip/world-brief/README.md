# 🌍 World Brief — 국제 주간 뉴스 브리핑

Claude AI가 매주 국제 이슈를 자동 정리하는 신문 스타일 Next.js 웹앱입니다.

---

## ✨ 주요 기능

- **버튼 클릭 한 번**으로 Claude AI가 최신 국제 뉴스 자동 생성
- 아메리카 / 중동·아프리카 / 유럽 / 아시아·태평양 섹션
- 🔴 긴급 / 🟡 주목 / 🟢 참고 중요도 분류
- **Vercel Cron**으로 매주 월요일 자동 업데이트 설정 가능
- Vercel KV 연결 시 뉴스 영구 저장 (없으면 메모리 저장)

---

## 🚀 배포 방법 (5단계)

### 1. Anthropic API 키 발급
https://console.anthropic.com 에서 API 키 발급

### 2. GitHub에 코드 올리기
```bash
git init
git add .
git commit -m "init: world brief"
git remote add origin https://github.com/YOUR_ID/world-brief.git
git push -u origin main
```

### 3. Vercel에 연결
1. https://vercel.com 접속 → 로그인
2. **Add New Project** → GitHub 저장소 선택
3. **Environment Variables** 추가:
   - `ANTHROPIC_API_KEY` = `sk-ant-...`
4. **Deploy** 클릭

→ 자동으로 `yoursite.vercel.app` 주소 생성!

### 4. (선택) 커스텀 .com 도메인 연결
1. Namecheap / Godaddy 등에서 도메인 구매 (연 1~2만원)
2. Vercel 대시보드 → Settings → Domains → 도메인 입력
3. DNS CNAME 레코드 설정 (Vercel 안내 따라)

### 5. (선택) Vercel KV 연결 — 뉴스 영구 저장
```bash
vercel storage create   # KV 스토리지 생성
vercel env pull         # 환경변수 자동 주입
```
KV 없이도 동작하지만, 서버 재시작 시 뉴스가 초기화됩니다.

---

## 💻 로컬 실행

```bash
npm install
cp .env.local.example .env.local
# .env.local에 ANTHROPIC_API_KEY 입력

npm run dev
# → http://localhost:3000
```

---

## 🔄 자동 업데이트 (Vercel Cron)

`vercel.json`에 이미 설정되어 있습니다:
- **매주 월요일 오전 9시 (KST)** 자동으로 뉴스 갱신

Vercel Pro 플랜에서 사용 가능합니다.
무료 플랜은 수동으로 버튼을 누르면 됩니다.

---

## 📁 파일 구조

```
world-brief/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── news/route.ts           ← GET: 저장된 브리핑 불러오기
│   │   │   └── generate-news/route.ts  ← POST: Claude로 뉴스 생성
│   │   ├── page.tsx                    ← 메인 페이지
│   │   └── globals.css
│   ├── components/
│   │   ├── Masthead.tsx                ← 신문 상단 헤더
│   │   ├── TopHeadline.tsx             ← 이번 주 최대 이슈
│   │   └── NewsSection.tsx             ← 카테고리별 뉴스 카드
│   └── lib/
│       ├── types.ts                    ← TypeScript 타입 정의
│       └── store.ts                    ← KV / 메모리 저장소
├── vercel.json                         ← Cron 설정
└── .env.local.example                  ← 환경변수 예시
```
