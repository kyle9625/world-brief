import { NextResponse } from 'next/server'
import { loadBrief } from '@/lib/store'

export const dynamic = 'force-dynamic'

export async function GET() {
  const brief = await loadBrief()
  return NextResponse.json(brief)
}
