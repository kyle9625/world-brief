import { NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'
import { saveBrief } from '@/lib/store'
import { WeeklyBrief } from '@/lib/types'

export const dynamic = 'force-dynamic'
export const maxDuration = 60  // seconds (Vercel Pro: 300)

// Helper: compute Korean week label
function getWeekLabel() {
  const now = new Date()
  const month = now.getMonth() + 1
  const day = now.getDate()
  const weekNum = Math.ceil(day / 7)
  const year = now.getFullYear()
  const start = new Date(now); start.setDate(day - now.getDay() + 1)
  const end   = new Date(now); end.setDate(day - now.getDay() + 7)
  const fmt = (d: Date) =>
    `${d.getFullYear()}.${String(d.getMonth()+1).padStart(2,'0')}.${String(d.getDate()).padStart(2,'0')}`
  return {
    weekLabel: `${year}년 ${month}월 ${weekNum}주차`,
    dateRange: `${fmt(start)} – ${fmt(end)}`,
  }
}

const SYSTEM_PROMPT = `You are a world-news editor producing a structured weekly international news brief.
Respond ONLY with a valid JSON object — no markdown fences, no preamble.

The JSON must match this TypeScript type exactly:
{
  weekLabel: string,
  dateRange: string,
  topHeadline: { kicker: string, title: string, deck: string },
  sections: Array<{
    category: string,
    emoji: string,
    items: Array<{
      id: string,           // unique slug e.g. "us-tariff-2026"
      region: string,       // e.g. "미국 · 무역"
      regionFlag: string,   // one emoji flag
      title: string,        // Korean headline, max 30 chars
      summary: string,      // Korean, 2-3 sentences, objective
      severity: "red"|"amber"|"green",
      source: string,       // e.g. "Reuters · AP"
      date: string          // "YYYY.MM.DD"
    }>
  }>,
  generatedAt: string       // ISO datetime
}

Sections to include (in order):
1. 아메리카  🌎
2. 중동·아프리카  🌍
3. 유럽  🇪🇺
4. 아시아·태평양  🌏

Each section: 3–5 items. Severity: red=urgent/breaking, amber=notable, green=informational.
topHeadline: the single most important story this week.
All text must be in Korean except source names and the generatedAt field.`

export async function POST(req: Request) {
  const apiKey = process.env.ANTHROPIC_API_KEY
  if (!apiKey) {
    return NextResponse.json({ error: 'ANTHROPIC_API_KEY not set' }, { status: 500 })
  }

  const client = new Anthropic({ apiKey })
  const { weekLabel, dateRange } = getWeekLabel()

  const userPrompt = `Today is ${new Date().toISOString().split('T')[0]}.
Generate the weekly international news brief for ${weekLabel} (${dateRange}).
Use your knowledge of the most recent and significant global events for this period.
Set weekLabel="${weekLabel}" and dateRange="${dateRange}" in the JSON.`

  try {
    const message = await client.messages.create({
      model: 'claude-opus-4-6',
      max_tokens: 4096,
      messages: [{ role: 'user', content: userPrompt }],
      system: SYSTEM_PROMPT,
    })

    const raw = (message.content[0] as { type: string; text: string }).text.trim()
    // Strip accidental markdown fences
    const clean = raw.replace(/^```(?:json)?\n?/, '').replace(/\n?```$/, '').trim()
    const brief: WeeklyBrief = JSON.parse(clean)

    await saveBrief(brief)
    return NextResponse.json({ ok: true, brief })
  } catch (err: any) {
    console.error('generate-news error', err)
    return NextResponse.json({ error: err.message ?? 'unknown error' }, { status: 500 })
  }
}
