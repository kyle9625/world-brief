import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'World Brief · 국제 주간 브리핑',
  description: '매주 Claude AI가 정리하는 국제 이슈 주간 브리핑',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ko">
      <body>{children}</body>
    </html>
  )
}
