'use client'
import { useState, useEffect, useCallback } from 'react'
import { WeeklyBrief, PLACEHOLDER_BRIEF } from '@/lib/types'
import Masthead from '@/components/Masthead'
import TopHeadline from '@/components/TopHeadline'
import NewsSection from '@/components/NewsSection'
import styles from './page.module.css'

export default function Home() {
  const [brief, setBrief]   = useState<WeeklyBrief>(PLACEHOLDER_BRIEF)
  const [loading, setLoading] = useState(false)
  const [toast, setToast]   = useState<string | null>(null)

  const showToast = (msg: string) => {
    setToast(msg)
    setTimeout(() => setToast(null), 4000)
  }

  // Load saved brief on mount
  useEffect(() => {
    fetch('/api/news')
      .then(r => r.json())
      .then((data: WeeklyBrief) => setBrief(data))
      .catch(() => {})
  }, [])

  const handleUpdate = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/generate-news', { method: 'POST' })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error ?? '서버 오류')
      setBrief(data.brief)
      showToast('✅ 이번 주 뉴스가 업데이트됐습니다!')
    } catch (err: any) {
      showToast(`❌ 오류: ${err.message}`)
    } finally {
      setLoading(false)
    }
  }, [])

  const lastUpdated = brief.generatedAt
    ? new Date(brief.generatedAt).toLocaleString('ko-KR', {
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit',
      })
    : '—'

  return (
    <>
      <Masthead
        weekLabel={brief.weekLabel}
        dateRange={brief.dateRange}
        onUpdate={handleUpdate}
        loading={loading}
        lastUpdated={lastUpdated}
      />

      {brief.sections.length > 0 && <TopHeadline brief={brief} />}

      <main className={styles.body}>
        {brief.sections.length === 0 ? (
          <div className={styles.empty}>
            <p>아직 이번 주 뉴스가 없습니다.</p>
            <p>상단 <strong>"이번 주 뉴스 업데이트"</strong> 버튼을 눌러 최신 국제 이슈를 불러오세요.</p>
            <button className={styles.bigBtn} onClick={handleUpdate} disabled={loading}>
              {loading ? '⏳ 생성 중…' : '🔄 지금 업데이트'}
            </button>
          </div>
        ) : (
          brief.sections.map((section) => (
            <NewsSection key={section.category} section={section} />
          ))
        )}

        <div className={styles.hint}>
          <strong>📌 매주 업데이트 방법</strong><br />
          상단 <em>"이번 주 뉴스 업데이트"</em> 버튼을 누르면 Claude AI가 최신 국제 이슈를 자동으로 정리합니다.
          Vercel Cron을 설정하면 매주 월요일 자동 실행도 가능합니다.
        </div>
      </main>

      <footer className={styles.footer}>
        WORLD BRIEF &nbsp;·&nbsp; 국제 주간 브리핑 &nbsp;|&nbsp; Powered by Claude AI
      </footer>

      {toast && <div className={styles.toast}>{toast}</div>}
    </>
  )
}
