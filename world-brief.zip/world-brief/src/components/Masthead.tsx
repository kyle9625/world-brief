'use client'
import styles from './Masthead.module.css'

interface Props {
  weekLabel: string
  dateRange: string
  onUpdate: () => void
  loading: boolean
  lastUpdated: string
}

export default function Masthead({ weekLabel, dateRange, onUpdate, loading, lastUpdated }: Props) {
  return (
    <header className={styles.masthead}>
      <div className={styles.editionBar}>
        <span>WORLD BRIEF · 국제 주간 브리핑</span>
        <span>{weekLabel}</span>
        <span>{dateRange}</span>
      </div>

      <div className={styles.title}>World Brief</div>
      <div className={styles.subtitle}>세계를 읽는 한 주의 시선 · International Weekly Digest</div>

      <hr className={styles.rule} />

      <div className={styles.bottomBar}>
        <span className={styles.updated}>
          최종 업데이트: {lastUpdated || '—'}
        </span>
        <button
          className={styles.updateBtn}
          onClick={onUpdate}
          disabled={loading}
        >
          {loading ? '⏳ 업데이트 중…' : '🔄 이번 주 뉴스 업데이트'}
        </button>
      </div>
    </header>
  )
}
