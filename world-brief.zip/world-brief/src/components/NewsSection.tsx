import { NewsSection as NewsSectionType } from '@/lib/types'
import styles from './NewsSection.module.css'

const BADGE_MAP = {
  red:   { label: '🔴 긴급', cls: 'badge-red' },
  amber: { label: '🟡 주목', cls: 'badge-amber' },
  green: { label: '🟢 참고', cls: 'badge-green' },
}

export default function NewsSection({ section }: { section: NewsSectionType }) {
  return (
    <section className={styles.section}>
      <div className={styles.sectionHead}>
        <h2 className={styles.sectionTitle}>{section.emoji} {section.category}</h2>
      </div>

      <div className={styles.grid}>
        {section.items.map((item) => {
          const badge = BADGE_MAP[item.severity]
          return (
            <article key={item.id} className={styles.card}>
              <span className={`badge ${badge.cls}`}>{badge.label}</span>
              <span className={styles.region}>{item.regionFlag} {item.region}</span>
              <h3 className={styles.cardTitle}>{item.title}</h3>
              <p className={styles.summary}>{item.summary}</p>
              <span className={styles.meta}>{item.source} — {item.date}</span>
            </article>
          )
        })}
      </div>
    </section>
  )
}
