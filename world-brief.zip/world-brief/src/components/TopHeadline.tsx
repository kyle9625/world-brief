import { WeeklyBrief } from '@/lib/types'
import styles from './TopHeadline.module.css'

export default function TopHeadline({ brief }: { brief: WeeklyBrief }) {
  const { kicker, title, deck } = brief.topHeadline
  return (
    <div className={styles.wrap}>
      <span className={styles.kicker}>{kicker}</span>
      <h1 className={styles.title}>{title}</h1>
      <p className={styles.deck}>{deck}</p>
    </div>
  )
}
