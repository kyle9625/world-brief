export type Severity = 'red' | 'amber' | 'green'

export interface NewsItem {
  id: string
  region: string
  regionFlag: string
  title: string
  summary: string
  severity: Severity
  source: string
  date: string
}

export interface NewsSection {
  category: string
  emoji: string
  items: NewsItem[]
}

export interface WeeklyBrief {
  weekLabel: string       // e.g. "2026년 2월 4주차"
  dateRange: string       // e.g. "2026.02.21 – 02.27"
  topHeadline: {
    kicker: string
    title: string
    deck: string
  }
  sections: NewsSection[]
  generatedAt: string     // ISO string
}

// ── Fallback / placeholder so the page always renders ──
export const PLACEHOLDER_BRIEF: WeeklyBrief = {
  weekLabel: '데이터 로딩 중',
  dateRange: '—',
  topHeadline: {
    kicker: '잠시만 기다려 주세요',
    title: '주간 브리핑을 불러오는 중입니다…',
    deck: '아직 이번 주 뉴스가 생성되지 않았습니다. 상단 "이번 주 뉴스 업데이트" 버튼을 눌러 최신 국제 이슈를 불러오세요.',
  },
  sections: [],
  generatedAt: new Date().toISOString(),
}
