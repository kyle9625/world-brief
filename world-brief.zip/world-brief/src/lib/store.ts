/**
 * Simple KV store abstraction.
 * On Vercel: uses Vercel KV (Redis) if REDIS_URL env var is present.
 * Locally / fallback: uses a module-level in-memory map.
 *
 * To enable Vercel KV:
 *   1. vercel storage create  (or connect in dashboard)
 *   2. vercel env pull        (populates KV_REST_API_URL etc.)
 *   The @vercel/kv package is auto-available on Vercel.
 */

import { WeeklyBrief, PLACEHOLDER_BRIEF } from './types'

// In-memory fallback (resets on cold start)
const memStore = new Map<string, string>()

const BRIEF_KEY = 'world-brief:latest'

async function getKV() {
  // Only import @vercel/kv if we're actually on Vercel with KV configured
  if (process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN) {
    try {
      const { kv } = await import('@vercel/kv')
      return kv
    } catch {
      // package not installed locally – fall through to mem store
    }
  }
  return null
}

export async function saveBrief(brief: WeeklyBrief): Promise<void> {
  const json = JSON.stringify(brief)
  const kv = await getKV()
  if (kv) {
    await (kv as any).set(BRIEF_KEY, json)
  } else {
    memStore.set(BRIEF_KEY, json)
  }
}

export async function loadBrief(): Promise<WeeklyBrief> {
  const kv = await getKV()
  let json: string | null = null
  if (kv) {
    json = await (kv as any).get(BRIEF_KEY)
  } else {
    json = memStore.get(BRIEF_KEY) ?? null
  }
  if (!json) return PLACEHOLDER_BRIEF
  try {
    return JSON.parse(json) as WeeklyBrief
  } catch {
    return PLACEHOLDER_BRIEF
  }
}
